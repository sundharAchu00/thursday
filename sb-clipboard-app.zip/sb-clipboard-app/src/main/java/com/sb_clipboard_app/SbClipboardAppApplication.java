package com.sb_clipboard_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbClipboardAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbClipboardAppApplication.class, args);
	}

}
